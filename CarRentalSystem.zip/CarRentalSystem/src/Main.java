import neu.edu.controller.CarRentalSystem;
import neu.edu.model.Car;

import java.text.ParseException;

public class Main {
    public static void main(String[] args) throws ParseException {
       CarRentalSystem.initializeCarRentalSystem();
    }
}
//2023-12-01
//2023-12-03