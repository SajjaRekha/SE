package neu.edu.controller;

import java.text.ParseException;

public class CarRentalSystem {
    public static void initializeCarRentalSystem() throws ParseException {

        CustomerController.initializaCustomerController();
    }

}
